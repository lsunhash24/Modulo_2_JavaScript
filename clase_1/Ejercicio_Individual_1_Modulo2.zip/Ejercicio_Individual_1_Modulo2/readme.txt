1. ¿Qué secciones identificas dentro del código?
 Dentro del código se identifican las siguientes secciones:
  <html></html> 
  <head></head> 
  <body></body> 
  <h1></h1>
  <p></p>  

2. ¿Puedes determinar, de acuerdo con el resultado, qué función cumple cada
sección del sitio?
  <html></html> etiqueta principal
  <head></head> etiqueta que proporciona informacion general del documento
                no se visualiza en el navegador
  <body></body> elemento con el contenido principal del documento
  <h1></h1> Título principal
  <p></p>   contiene párrafo

3. Abre el archivo usando el Bloc de Notas del computador ¿qué diferencias
puedes apreciar entre una herramienta y la otra? A tu juicio ¿cuál aplicación
brinda mayores beneficios?
  A diferencia del bloc de notas el Ide de Visual Studio code es mucho más eficiente 
  para trabajar con código, tiene autocompletado, visualizador de estructura, número de 
  línea, gestor de archivos y muchos mas. Por tanto, Vsc es el que brinda mayores 
  beneficios.

4. ¿Qué sucedería al cambiar la palabra “green” por “blue” en la línea 9? ¿Y si
cambiamos la palabra “Arial” por “Verdana” en la línea siguiente?
  Al aplicar estos cambios se cambia de color azul el fondo y el tipo de fuente
  de todo lo que contiene el body.

5. Ingresa el texto que desee entre las líneas 23 y 24 del archivo, guárdalo y
recarga el sitio desde el navegador. ¿Qué efectos pudiste notar? ¿Qué otros
efectos se pueden añadir a dicho texto?
 Se agregó párrafo a continuacón del anterior, aunque quedó fuera del body. otros
 efectos que se pueden aplicar al texto es negrita (b), cursiva (i), subrayado (u).
 Se observa que el color azul del fondo también se aplica en esta sección. 

