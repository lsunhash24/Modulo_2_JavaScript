Integrantes:
Francisco Ortega
Patricio Foitzick
Luis Sanhueza