Integrantes:
Valentina Urrutia M
Francisco Ortega
Patricio Foitzick
Luis Sanhueza